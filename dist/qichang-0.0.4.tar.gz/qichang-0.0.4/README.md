# This is a personal library developed by Qichang Zheng.
## Installation
```bash
pip install qichang
```